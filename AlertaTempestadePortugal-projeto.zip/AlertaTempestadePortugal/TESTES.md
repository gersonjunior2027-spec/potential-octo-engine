# Testes

## 1. Automáticos (no computador)
```
./gradlew testDebugUnitTest
```
Verificam: leitura dos avisos do IPMA, filtro por zona/nível/validade, avisos verdes ignorados, avisos «outros» (calor, etc.) sem alarme, textos por nível, não repetir o mesmo alerta (mas sim em subida de nível), alerta de vento medido (limite, observação recente), zona mais próxima, estação mais próxima, leitura da previsão.

## 2. No telemóvel (RedMagic) — alarme e notificações sem esperar por uma tempestade
Separador **Definições › Testes**:

| # | Passos | Resultado esperado |
|---|---|---|
| 1 | «Testar só a notificação» | Notificação «ALERTA VERMELHO! (TESTE)» sem som |
| 2 | «Testar alarme» | Toca o toque de chamada em ciclo; vibra; aparece o cartão vermelho **DESLIGAR** na app e a notificação com botão DESLIGAR |
| 3 | Deixar tocar 30 s, sem tocar em nada | Continua a tocar (repete) |
| 4 | Carregar em DESLIGAR (na app **ou** na notificação) | Para o som e a vibração; a monitorização continua ativa (se estava ligada) |
| 5 | «Testar alarme», bloquear o ecrã de imediato | Continua a tocar com o ecrã bloqueado; ecrã liga com o alarme (se o ecrã inteiro estiver permitido); DESLIGAR funciona |
| 6 | «Testar alarme», carregar no botão Início | Continua a tocar em segundo plano |
| 7 | Alterar o volume (Definições) e testar | Volume diferente |
| 8 | Escolher outro som e testar | Toca o som escolhido |

## 3. Monitorização
| # | Passos | Resultado esperado |
|---|---|---|
| 9 | «Iniciar monitorização» | Notificação permanente «Sem alertas ativos · … verificado às HH:mm» |
| 10 | Desligar dados móveis e Wi-Fi, «Atualizar agora» | «Sem ligação à Internet» e «DADOS DESATUALIZADOS» com a hora da última atualização |
| 11 | Desativar GPS em Definições | Só aparece o Porto |
| 12 | Com GPS ativo, sair para o exterior e andar alguns km | A zona de aviso e «Atualizado às» mudam |
| 13 | Reiniciar o telemóvel (monitorização estava ligada) | A notificação permanente volta sozinha |
| 14 | Fechar a app nos Recentes (com o cadeado) | A monitorização continua |
| 15 | Quando existir um aviso real no IPMA para o Porto | Alarme + notificação com o motivo; não volta a tocar na verificação seguinte |
| 16 | Comparar com ipma.pt › Avisos | Mesmos avisos e níveis para a zona |
