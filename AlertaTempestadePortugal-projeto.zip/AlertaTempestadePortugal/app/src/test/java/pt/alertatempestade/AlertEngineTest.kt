package pt.alertatempestade

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import pt.alertatempestade.data.AlertEngine
import pt.alertatempestade.data.AlertSource
import pt.alertatempestade.data.Area
import pt.alertatempestade.data.IpmaParser
import pt.alertatempestade.data.Level
import pt.alertatempestade.data.Observation
import pt.alertatempestade.data.RawObservation
import pt.alertatempestade.data.Station
import pt.alertatempestade.data.WarnType
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneOffset

class AlertEngineTest {

    // Formato dos avisos do IPMA (warnings_www.json).
    private val warningsJson = """
    [
      {"text":"","awarenessTypeName":"Trovoada","idAreaAviso":"PTO","startTime":"2026-11-11T09:00:00","awarenessLevelID":"orange","endTime":"2026-11-11T18:00:00"},
      {"text":"","awarenessTypeName":"Vento","idAreaAviso":"PTO","startTime":"2026-11-11T09:00:00","awarenessLevelID":"green","endTime":"2026-11-11T18:00:00"},
      {"text":"","awarenessTypeName":"Precipitação","idAreaAviso":"LSB","startTime":"2026-11-11T09:00:00","awarenessLevelID":"red","endTime":"2026-11-11T18:00:00"},
      {"text":"","awarenessTypeName":"Tempo Quente","idAreaAviso":"PTO","startTime":"2026-11-11T09:00:00","awarenessLevelID":"yellow","endTime":"2026-11-11T18:00:00"},
      {"text":"","awarenessTypeName":"Vento","idAreaAviso":"PTO","startTime":"2026-11-12T09:00:00","awarenessLevelID":"red","endTime":"2026-11-12T18:00:00"}
    ]
    """.trimIndent()

    private val noon: Instant = IpmaParser.parseLocalTime("2026-11-11T12:00:00")!!

    @Test fun parsesAllWarnings() {
        assertEquals(5, IpmaParser.parseWarnings(warningsJson).size)
    }

    @Test fun classifiesTypesIgnoringAccents() {
        assertEquals(WarnType.THUNDER, IpmaParser.classify("Trovoada"))
        assertEquals(WarnType.WIND, IpmaParser.classify("Vento"))
        assertEquals(WarnType.RAIN, IpmaParser.classify("Precipitação"))
        assertEquals(WarnType.OTHER, IpmaParser.classify("Tempo Quente"))
    }

    @Test fun onlyActiveYellowOrangeRedOfTheAreaAreKept() {
        val w = IpmaParser.parseWarnings(warningsJson)
        val active = AlertEngine.activeWarnings(w, "PTO", noon)
        // Porto: trovoada laranja + tempo quente amarelo. Fora: vento verde, Lisboa, vento de amanhã.
        assertEquals(2, active.size)
        assertTrue(active.any { it.type == WarnType.THUNDER && it.level == Level.ORANGE })
        assertFalse(active.any { it.level == Level.GREEN })
    }

    @Test fun expiredAndFutureWarningsAreIgnored() {
        val w = IpmaParser.parseWarnings(warningsJson)
        val evening = IpmaParser.parseLocalTime("2026-11-11T19:00:00")!!
        assertTrue(AlertEngine.activeWarnings(w, "PTO", evening).isEmpty())
        val early = IpmaParser.parseLocalTime("2026-11-11T08:00:00")!!
        assertTrue(AlertEngine.activeWarnings(w, "PTO", early).isEmpty())
    }

    @Test fun otherWarningTypesDoNotRing() {
        val w = IpmaParser.parseWarnings(warningsJson)
        val heat = AlertEngine.activeWarnings(w, "PTO", noon).first { it.type == WarnType.OTHER }
        val item = AlertEngine.fromWarning(heat, "Porto")
        assertFalse(AlertEngine.shouldRing(item, 1))
    }

    @Test fun thunderOrangeRingsAndTextsAreCorrect() {
        val w = IpmaParser.parseWarnings(warningsJson)
        val t = AlertEngine.activeWarnings(w, "PTO", noon).first { it.type == WarnType.THUNDER }
        val item = AlertEngine.fromWarning(t, "Porto")
        assertEquals("ALERTA LARANJA!", item.title)
        assertEquals("Trovoadas fortes e possibilidade de raios.", item.body)
        assertTrue(AlertEngine.shouldRing(item, 1))
        assertTrue(AlertEngine.shouldRing(item, 2))
        assertFalse(AlertEngine.shouldRing(item, 3))
    }

    @Test fun messagesPerLevel() {
        assertEquals("Possibilidade de trovoadas.", AlertEngine.message(WarnType.THUNDER, Level.YELLOW, "Trovoada"))
        assertEquals("Ventos fortes e rajadas perigosas.", AlertEngine.message(WarnType.WIND, Level.ORANGE, "Vento"))
        assertEquals("Tempestade severa com trovoada.", AlertEngine.message(WarnType.THUNDER, Level.RED, "Trovoada"))
    }

    @Test fun sameAlertIsNotNotifiedTwiceButEscalationIs() {
        val w = IpmaParser.parseWarnings(warningsJson)
        val t = AlertEngine.activeWarnings(w, "PTO", noon).first { it.type == WarnType.THUNDER }
        val item = AlertEngine.fromWarning(t, "Porto")
        assertEquals(1, AlertEngine.fresh(listOf(item), emptySet()).size)
        assertTrue(AlertEngine.fresh(listOf(item), setOf(item.key)).isEmpty())
        val red = AlertEngine.fromWarning(t.copy(level = Level.RED), "Porto")
        assertEquals(1, AlertEngine.fresh(listOf(red), setOf(item.key)).size)
    }

    @Test fun windAlertOnlyWithRecentObservationAboveThreshold() {
        val today = LocalDate.of(2026, 11, 11)
        val fresh = Observation("Porto, Pedras Rubras", noon.minusSeconds(1800), 14.0, 72.0, 80.0, 8.0)
        val a = AlertEngine.windAlert(fresh, 60, noon, today)
        assertNotNull(a)
        assertEquals(AlertSource.WIND_MEASURED, a!!.source)
        assertEquals(Level.YELLOW, a.level)
        assertEquals(Level.ORANGE, AlertEngine.windAlert(fresh.copy(windKmh = 85.0), 60, noon, today)!!.level)
        assertNull(AlertEngine.windAlert(fresh.copy(windKmh = 40.0), 60, noon, today))
        val old = fresh.copy(time = noon.minusSeconds(5 * 3600))
        assertNull(AlertEngine.windAlert(old, 60, noon, today))
        assertNull(AlertEngine.windAlert(null, 60, noon, today))
    }

    @Test fun testAlertAlwaysRings() {
        val t = AlertEngine.testAlert(1L)
        assertTrue(AlertEngine.shouldRing(t, 3))
    }

    @Test fun nearestAreaPicksPortoNearPorto() {
        val areas = listOf(
            Area(1, "LSB", "Lisboa", 38.72, -9.14),
            Area(2, "PTO", "Porto", 41.15, -8.61),
            Area(3, "BRG", "Braga", 41.55, -8.42)
        )
        val (a, d) = AlertEngine.nearestArea(areas, 41.20, -8.65)!!
        assertEquals("PTO", a.areaId)
        assertTrue(d < 10.0)
    }

    @Test fun parsesAreasWithAndWithoutAreaCode() {
        val json = """{"data":[
          {"globalIdLocal":1131200,"latitude":"41.1496","local":"Porto","longitude":"-8.6109","idAreaAviso":"PTO"},
          {"globalIdLocal":1080500,"latitude":"37.0194","local":"Faro","longitude":"-7.9304"}
        ]}"""
        val areas = IpmaParser.parseAreas(json)
        assertEquals(2, areas.size)
        assertEquals("PTO", areas[0].areaId)
        assertEquals("FAR", areas[1].areaId) // código obtido pelo nome
    }

    @Test fun parsesLatestObservationsAndSkipsInvalidValues() {
        val json = """{
          "2026-11-11T09:00": {"111": {"temperatura": 14.5, "intensidadeVentoKM": -99.0, "humidade": 80.0}, "222": null},
          "2026-11-11T10:00": {"111": {"temperatura": 15.0, "intensidadeVentoKM": 33.0, "humidade": 78.0}, "222": {"temperatura": -99.0, "intensidadeVentoKM": -99.0, "humidade": -99.0}}
        }"""
        val o = IpmaParser.parseLatestObservations(json)
        assertEquals(33.0, o["111"]!!.windKmh!!, 0.001)
        assertEquals(LocalDateTime.of(2026, 11, 11, 10, 0).toInstant(ZoneOffset.UTC), o["111"]!!.time)
        assertNull(o["222"])
    }

    @Test fun nearestStationRespectsMaxDistance() {
        val stations = listOf(Station("1", "Perto", 41.2, -8.6), Station("2", "Longe", 38.7, -9.1))
        val obs = mapOf(
            "1" to RawObservation(noon, 14.0, 20.0, 70.0),
            "2" to RawObservation(noon, 18.0, 50.0, 60.0)
        )
        val o = AlertEngine.nearestStation(stations, obs, 41.15, -8.61)
        assertEquals("Perto", o!!.stationName)
        assertNull(AlertEngine.nearestStation(stations, obs, 39.5, -8.0))
    }

    @Test fun parsesForecastAndSelectsToday() {
        val json = """{"data":[
          {"precipitaProb":"10.0","tMin":"10.1","tMax":"17.0","predWindDir":"N","idWeatherType":3,"classWindSpeed":2,"forecastDate":"2026-11-10"},
          {"precipitaProb":"70.0","tMin":"11.0","tMax":"16.0","predWindDir":"SW","idWeatherType":9,"classWindSpeed":3,"forecastDate":"2026-11-11"}
        ]}"""
        val f = IpmaParser.parseForecast(json, "2026-11-11")!!
        assertEquals("2026-11-11", f.date)
        assertEquals(3, f.windClass)
        assertEquals(9, f.weatherTypeId)
    }
}
