package pt.alertatempestade.data

import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Lógica pura dos alertas (sem Android): filtragem, textos, deduplicação, decisão de tocar. */
object AlertEngine {
    private val HOUR_FMT: DateTimeFormatter =
        DateTimeFormatter.ofPattern("HH:mm dd/MM").withZone(IpmaParser.LISBON)

    /** Avisos oficiais amarelo/laranja/vermelho, da zona indicada, em vigor neste momento. */
    fun activeWarnings(all: List<Warning>, areaId: String, now: Instant): List<Warning> =
        all.filter {
            it.areaId == areaId && it.level.rank >= Level.YELLOW.rank &&
                !now.isBefore(it.start) && now.isBefore(it.end)
        }

    fun message(type: WarnType, level: Level, typeName: String): String = when (type) {
        WarnType.THUNDER -> when (level) {
            Level.RED -> "Tempestade severa com trovoada."
            Level.ORANGE -> "Trovoadas fortes e possibilidade de raios."
            else -> "Possibilidade de trovoadas."
        }
        WarnType.WIND -> when (level) {
            Level.RED -> "Ventos muito fortes e rajadas perigosas."
            Level.ORANGE -> "Ventos fortes e rajadas perigosas."
            else -> "Vento forte."
        }
        WarnType.RAIN -> when (level) {
            Level.RED -> "Chuva muito intensa. Risco de inundações."
            Level.ORANGE -> "Chuva intensa."
            else -> "Possibilidade de chuva forte."
        }
        WarnType.OTHER -> "Aviso de $typeName."
    }

    fun fromWarning(w: Warning, areaName: String): AlertItem {
        val key = "w|${w.areaId}|${w.typeName}|${w.level.name}|${w.start.epochSecond}|${w.end.epochSecond}"
        val detail = "Aviso ${w.level.pt} do IPMA (${w.typeName}) para $areaName, válido até ${HOUR_FMT.format(w.end)}."
        return AlertItem(
            key = key,
            source = AlertSource.OFFICIAL,
            level = w.level,
            type = w.type,
            title = "ALERTA ${w.level.pt.uppercase()}!",
            body = message(w.type, w.level, w.typeName),
            detail = if (w.text.isBlank()) detail else "$detail ${w.text}",
            heading = "${w.typeName} — ${w.level.pt}",
            endsAt = w.end
        )
    }

    /**
     * Alerta adicional definido pelo utilizador: vento MEDIDO (não é aviso oficial) acima do limite.
     * Só com observações recentes (máx. 3 h).
     */
    fun windAlert(obs: Observation?, thresholdKmh: Int, now: Instant, today: LocalDate): AlertItem? {
        if (obs == null) return null
        val wind = obs.windKmh ?: return null
        if (now.epochSecond - obs.time.epochSecond > 3 * 3600) return null
        if (wind < thresholdKmh) return null
        val high = wind >= thresholdKmh + 20
        val level = if (high) Level.ORANGE else Level.YELLOW
        return AlertItem(
            key = "wind|${obs.stationName}|$today|${if (high) "hi" else "lo"}",
            source = AlertSource.WIND_MEASURED,
            level = level,
            type = WarnType.WIND,
            title = "ALERTA ${level.pt.uppercase()}!",
            body = "Vento medido de ${wind.toInt()} km/h (limite definido: $thresholdKmh km/h).",
            detail = "Medição da estação do IPMA ${obs.stationName}, a ${obs.distanceKm.toInt()} km. " +
                "Não é um aviso oficial: é um limite definido por si.",
            heading = "Vento medido — ${level.pt}",
            endsAt = now.plusSeconds(3 * 3600)
        )
    }

    fun testAlert(nowMillis: Long): AlertItem = AlertItem(
        key = "test|$nowMillis",
        source = AlertSource.TEST,
        level = Level.RED,
        type = WarnType.THUNDER,
        title = "ALERTA VERMELHO! (TESTE)",
        body = "Teste do alarme. Carregue em DESLIGAR.",
        detail = "Este é apenas um teste: não existe nenhum aviso real.",
        heading = "Teste — Vermelho",
        endsAt = null
    )

    /** Só toca se o alerta for de emergência e atingir o nível mínimo escolhido. */
    fun shouldRing(a: AlertItem, minLevelRank: Int): Boolean =
        (a.type.emergency || a.source == AlertSource.TEST) && a.level.rank >= minLevelRank

    /** Alertas que ainda não foram notificados (evita tocar de novo sem haver novidade). */
    fun fresh(alerts: List<AlertItem>, notified: Set<String>): List<AlertItem> =
        alerts.filter { it.key !in notified }

    fun stillActive(alerts: List<AlertItem>, now: Instant): List<AlertItem> =
        alerts.filter { it.endsAt == null || now.isBefore(it.endsAt) }

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * atan2(sqrt(a), sqrt(1 - a))
    }

    fun nearestArea(areas: List<Area>, lat: Double, lon: Double): Pair<Area, Double>? =
        areas.map { it to haversineKm(lat, lon, it.lat, it.lon) }.minByOrNull { it.second }

    fun nearestStation(
        stations: List<Station>,
        obs: Map<String, RawObservation>,
        lat: Double,
        lon: Double,
        maxKm: Double = 60.0
    ): Observation? {
        var best: Observation? = null
        for (s in stations) {
            val o = obs[s.id] ?: continue
            val d = haversineKm(lat, lon, s.lat, s.lon)
            if (d > maxKm) continue
            if (best == null || d < best.distanceKm) {
                best = Observation(s.name, o.time, o.temp, o.windKmh, o.humidity, d)
            }
        }
        return best
    }
}
