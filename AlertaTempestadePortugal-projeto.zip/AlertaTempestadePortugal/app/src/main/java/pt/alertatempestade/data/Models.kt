package pt.alertatempestade.data

import java.time.Instant

enum class Level(val rank: Int, val pt: String) {
    GREEN(0, "Verde"),
    YELLOW(1, "Amarelo"),
    ORANGE(2, "Laranja"),
    RED(3, "Vermelho");

    companion object {
        fun fromIpma(s: String?): Level = when (s?.trim()?.lowercase()) {
            "yellow" -> YELLOW
            "orange" -> ORANGE
            "red" -> RED
            else -> GREEN
        }

        fun fromRank(r: Int): Level = entries.firstOrNull { it.rank == r } ?: YELLOW
    }
}

/** Tipos de aviso que consideramos de emergência (tocam alarme). OTHER só aparece na lista. */
enum class WarnType(val label: String, val emergency: Boolean) {
    THUNDER("Trovoada", true),
    WIND("Vento", true),
    RAIN("Precipitação intensa", true),
    OTHER("Outro aviso", false)
}

enum class AlertSource { OFFICIAL, WIND_MEASURED, TEST }

/** Aviso oficial tal como publicado pelo IPMA. */
data class Warning(
    val areaId: String,
    val typeName: String,
    val type: WarnType,
    val level: Level,
    val start: Instant,
    val end: Instant,
    val text: String
)

data class Area(
    val globalIdLocal: Int,
    val areaId: String,
    val name: String,
    val lat: Double,
    val lon: Double
)

data class DailyForecast(
    val date: String,
    val tMin: String?,
    val tMax: String?,
    val precipProb: String?,
    val windDir: String?,
    val windClass: Int?,
    val weatherTypeId: Int?
)

data class Station(val id: String, val name: String, val lat: Double, val lon: Double)

data class RawObservation(
    val time: Instant,
    val temp: Double?,
    val windKmh: Double?,
    val humidity: Double?
)

data class Observation(
    val stationName: String,
    val time: Instant,
    val temp: Double?,
    val windKmh: Double?,
    val humidity: Double?,
    val distanceKm: Double
)

data class LocationFix(val lat: Double, val lon: Double, val timeMillis: Long)

/** Alerta pronto a mostrar / notificar / tocar. */
data class AlertItem(
    val key: String,
    val source: AlertSource,
    val level: Level,
    val type: WarnType,
    val title: String,      // ex.: "ALERTA LARANJA!"
    val body: String,       // ex.: "Ventos fortes e rajadas perigosas."
    val detail: String,     // ex.: "Aviso Laranja do IPMA (Vento) para Porto, válido até 18:00."
    val heading: String,    // ex.: "Vento — Laranja"
    val endsAt: Instant?
)

data class PlaceStatus(
    val id: String,
    val label: String,
    val areaName: String? = null,
    val areaId: String? = null,
    val alerts: List<AlertItem> = emptyList(),
    val otherWarnings: List<AlertItem> = emptyList(),
    val forecast: DailyForecast? = null,
    val forecastDesc: String? = null,
    val observation: Observation? = null,
    val fetchedAt: Long = 0L,
    val problem: String? = null,
    val stale: Boolean = false,
    val note: String? = null,
    val hasData: Boolean = false
)

data class AlarmInfo(val alerts: List<AlertItem>, val test: Boolean)
