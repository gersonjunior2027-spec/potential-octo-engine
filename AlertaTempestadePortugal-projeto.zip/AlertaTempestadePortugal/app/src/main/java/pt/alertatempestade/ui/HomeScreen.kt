package pt.alertatempestade.ui

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import pt.alertatempestade.data.AlarmInfo
import pt.alertatempestade.data.AlertItem
import pt.alertatempestade.data.AppSettings
import pt.alertatempestade.data.AppState
import pt.alertatempestade.data.Checker
import pt.alertatempestade.data.IpmaParser
import pt.alertatempestade.data.PlaceStatus
import pt.alertatempestade.service.LocationTracker
import pt.alertatempestade.service.MonitorService
import java.time.Instant
import java.time.format.DateTimeFormatter

private val HM: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm").withZone(IpmaParser.LISBON)

/** Atualização manual sem alarme (usada quando a monitorização está desligada). */
suspend fun manualRefresh(ctx: Context) {
    if (!AppState.refreshing.compareAndSet(false, true)) return
    try {
        val s = AppSettings(ctx)
        val fix = if (s.monitorGps) AppState.lastFix.value ?: LocationTracker.lastKnown(ctx) else null
        val prev = AppState.places.value.associateBy { it.id }
        AppState.places.value = Checker(s).run(fix, prev)
    } finally {
        AppState.refreshing.value = false
    }
}

@Composable
fun HomeScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    val settings = remember { AppSettings(ctx) }
    val places by AppState.places.collectAsStateWithLifecycle()
    val alarm by AppState.alarm.collectAsStateWithLifecycle()
    val monitoring by AppState.monitoring.collectAsStateWithLifecycle()
    val refreshing by AppState.refreshing.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val nowMs by produceState(System.currentTimeMillis()) {
        while (true) { delay(30_000); value = System.currentTimeMillis() }
    }

    LaunchedEffect(Unit) {
        if (settings.monitoringEnabled) MonitorService.requestCheck(ctx) else manualRefresh(ctx)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(pad),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Alerta Tempestade Portugal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        alarm?.let { a ->
            item { AlarmBanner(a) { MonitorService.stopAlarm(ctx) } }
        }
        item { PermissionsCard() }
        item {
            MonitorCard(
                monitoring = monitoring,
                refreshing = refreshing,
                onToggle = {
                    if (monitoring) MonitorService.stopMonitoring(ctx) else MonitorService.start(ctx)
                },
                onRefresh = {
                    if (monitoring) MonitorService.requestCheck(ctx) else scope.launch { manualRefresh(ctx) }
                }
            )
        }
        if (places.isEmpty()) {
            item {
                Text(
                    if (refreshing) "A obter dados oficiais do IPMA…"
                    else "Sem localizações ativas. Ative o Porto ou o GPS em Definições.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        items(places, key = { it.id }) { p -> PlaceCard(p, settings.intervalMin, nowMs) }
        item {
            Text(
                "Fonte: IPMA – Instituto Português do Mar e da Atmosfera (API aberta oficial). " +
                    "A posição GPS não é enviada a ninguém. Em caso de perigo, siga as indicações da Proteção Civil (112).",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun AlarmBanner(a: AlarmInfo, onStop: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = RedAlert), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (a.test) "ALARME DE TESTE A TOCAR" else "ALARME ATIVO",
                color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp
            )
            a.alerts.forEach {
                Text(it.title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(it.body, color = Color.White)
            }
            Button(
                onClick = onStop,
                modifier = Modifier.fillMaxWidth().height(64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = RedAlert)
            ) {
                Text("DESLIGAR", fontWeight = FontWeight.Black, fontSize = 22.sp)
            }
            Text(
                "Desligar o alarme não pára a monitorização. Só volta a tocar com um alerta novo.",
                color = Color.White, style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun MonitorCard(monitoring: Boolean, refreshing: Boolean, onToggle: () -> Unit, onRefresh: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(12.dp).background(if (monitoring) GreenOk else Color.Gray, CircleShape)
                )
                Spacer(Modifier.size(8.dp))
                Text(
                    if (monitoring) "Monitorização ATIVA" else "Monitorização DESLIGADA",
                    fontWeight = FontWeight.Bold
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onToggle, modifier = Modifier.weight(1f)) {
                    Text(if (monitoring) "Parar" else "Iniciar monitorização")
                }
                OutlinedButton(onClick = onRefresh, enabled = !refreshing, modifier = Modifier.weight(1f)) {
                    Text(if (refreshing) "A atualizar…" else "Atualizar agora")
                }
            }
            if (!monitoring) {
                Text(
                    "Com a monitorização desligada não há alarmes nem verificações em segundo plano.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun PlaceCard(p: PlaceStatus, intervalMin: Int, nowMs: Long) {
    val tooOld = p.fetchedAt > 0 && nowMs - p.fetchedAt > (intervalMin * 2.5 * 60_000).toLong()
    val outdated = p.stale || (p.hasData && tooOld)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(p.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (p.areaName != null) {
                Text("Zona de aviso: ${p.areaName}", style = MaterialTheme.typography.bodySmall)
            }
            p.note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            if (p.problem != null) {
                Text(p.problem, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
            }
            if (outdated && p.fetchedAt > 0) {
                Text(
                    "DADOS DESATUALIZADOS — última atualização às ${HM.format(Instant.ofEpochMilli(p.fetchedAt))}.",
                    color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold
                )
            } else if (p.fetchedAt > 0) {
                Text("Atualizado às ${HM.format(Instant.ofEpochMilli(p.fetchedAt))}", style = MaterialTheme.typography.bodySmall)
            }

            if (p.hasData || p.alerts.isNotEmpty()) {
                if (p.alerts.isEmpty() && p.otherWarnings.isEmpty() && p.areaName != null) {
                    Text("Sem avisos oficiais ativos de trovoada, vento ou chuva.", color = GreenOk, fontWeight = FontWeight.SemiBold)
                }
                p.alerts.forEach { AlertRow(it) }
                if (p.otherWarnings.isNotEmpty()) {
                    Text("Outros avisos oficiais (sem alarme):", style = MaterialTheme.typography.labelLarge)
                    p.otherWarnings.forEach { AlertRow(it) }
                }
            }

            p.observation?.let { o ->
                val parts = listOfNotNull(
                    o.temp?.let { "${"%.1f".format(it)} °C" },
                    o.windKmh?.let { "vento ${it.toInt()} km/h" },
                    o.humidity?.let { "humidade ${it.toInt()}%" }
                )
                if (parts.isNotEmpty()) {
                    Text("Medido agora (${o.stationName}, ${o.distanceKm.toInt()} km, ${HM.format(o.time)}):", style = MaterialTheme.typography.labelLarge)
                    Text(parts.joinToString(" · "))
                }
            }

            p.forecast?.let { f ->
                Text("Previsão de hoje (não é um aviso oficial):", style = MaterialTheme.typography.labelLarge)
                val wind = when (f.windClass) {
                    1 -> "vento fraco"; 2 -> "vento moderado"; 3 -> "vento forte"; 4 -> "vento muito forte"; else -> null
                }
                val line = listOfNotNull(
                    p.forecastDesc?.takeIf { it.isNotBlank() && it != "---" },
                    if (f.tMin != null && f.tMax != null) "${f.tMin}° / ${f.tMax}°C" else null,
                    f.precipProb?.let { "prob. precipitação $it%" },
                    wind
                ).joinToString(" · ")
                if (line.isNotBlank()) Text(line)
            }
        }
    }
}

@Composable
private fun AlertRow(a: AlertItem) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(width = 8.dp, height = 56.dp).background(levelColor(a.level), CircleShape))
        Column {
            Text("${a.heading}", fontWeight = FontWeight.Bold)
            Text(a.body)
            Text(a.detail, style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ------------------------------------------------------------------ permissões

private fun has(ctx: Context, p: String) =
    ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

@Composable
private fun PermissionsCard() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    @Suppress("UNUSED_VARIABLE") val t = tick // força nova leitura ao voltar das definições
    val notifOk = Build.VERSION.SDK_INT < 33 || has(ctx, Manifest.permission.POST_NOTIFICATIONS)
    val locOk = has(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
    val bgOk = Build.VERSION.SDK_INT < 29 || has(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    val battOk = (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    val fsiOk = Build.VERSION.SDK_INT < 34 ||
        ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    if (notifOk && locOk && bgOk && battOk && fsiOk) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Configuração necessária para os alarmes funcionarem", fontWeight = FontWeight.Bold)
            if (!notifOk) PermRow("Permitir notificações") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (!locOk) PermRow("Permitir localização (GPS)") {
                locLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
            if (locOk && !bgOk) PermRow("Localização «Permitir sempre» (necessária com o ecrã bloqueado)") {
                bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            }
            if (!battOk) PermRow("Sem restrições de bateria (evita que o sistema pare a monitorização)") {
                ctx.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
            if (!fsiOk) PermRow("Permitir alertas em ecrã inteiro (alarme com o telemóvel bloqueado)") {
                if (Build.VERSION.SDK_INT >= 34) {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            Text("No RedMagic há passos extra: veja o separador Ajuda.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun PermRow(text: String, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Button(onClick = onClick) { Text("Permitir") }
    }
}
