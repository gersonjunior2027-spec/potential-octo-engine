package pt.alertatempestade.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import pt.alertatempestade.data.AlarmInfo
import pt.alertatempestade.data.AlertEngine
import pt.alertatempestade.data.AlertItem
import pt.alertatempestade.data.AppSettings
import pt.alertatempestade.data.AppState
import pt.alertatempestade.data.Checker
import pt.alertatempestade.data.IpmaParser
import pt.alertatempestade.data.LocationFix
import java.time.Instant
import java.time.format.DateTimeFormatter

/**
 * Serviço em primeiro plano: monitoriza o IPMA, segue a posição GPS e toca o alarme
 * (repetido até o utilizador carregar em DESLIGAR) quando surge um alerta NOVO.
 */
class MonitorService : Service() {

    companion object {
        const val ACTION_START = "pt.alertatempestade.START"
        const val ACTION_STOP_MONITOR = "pt.alertatempestade.STOP_MONITOR"
        const val ACTION_CHECK = "pt.alertatempestade.CHECK"
        const val ACTION_STOP_ALARM = "pt.alertatempestade.STOP_ALARM"
        const val ACTION_TEST_ALARM = "pt.alertatempestade.TEST_ALARM"
        const val ACTION_TEST_NOTIFICATION = "pt.alertatempestade.TEST_NOTIFICATION"

        private fun send(ctx: Context, action: String) {
            val i = Intent(ctx, MonitorService::class.java).setAction(action)
            try { ContextCompat.startForegroundService(ctx, i) } catch (e: Exception) { /* restrições do sistema */ }
        }

        fun start(ctx: Context) = send(ctx, ACTION_START)
        fun stopMonitoring(ctx: Context) = send(ctx, ACTION_STOP_MONITOR)
        fun requestCheck(ctx: Context) = send(ctx, ACTION_CHECK)
        fun stopAlarm(ctx: Context) = send(ctx, ACTION_STOP_ALARM)
        fun testAlarm(ctx: Context) = send(ctx, ACTION_TEST_ALARM)
        fun testNotification(ctx: Context) = send(ctx, ACTION_TEST_NOTIFICATION)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()
    private lateinit var settings: AppSettings
    private lateinit var tracker: LocationTracker
    private lateinit var player: AlarmPlayer
    private var lastEvaluatedFix: LocationFix? = null
    private var lastCheckAt = 0L
    private var checkJob: Job? = null
    private var foregroundOn = false
    private val postedAlerts = LinkedHashMap<String, AlertItem>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        settings = AppSettings(this)
        player = AlarmPlayer(this)
        tracker = LocationTracker(this) { fix -> onNewFix(fix) }
        Notifier.createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Reinício automático do sistema (intent nulo): só continua se o utilizador tinha a monitorização ligada.
        val action = intent?.action ?: if (settings.monitoringEnabled) ACTION_CHECK else {
            stopSelf()
            return START_NOT_STICKY
        }
        when (action) {
            ACTION_STOP_MONITOR -> {
                settings.monitoringEnabled = false
                AppState.monitoring.value = false
                cancelNextCheck()
                tracker.stop()
                stopAlarmInternal()
                stopForegroundSafely()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_ALARM -> {
                ensureForeground("A desligar o alarme…")
                stopAlarmInternal()
                if (!settings.monitoringEnabled) {
                    stopForegroundSafely()
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            ACTION_TEST_ALARM -> {
                ensureForeground("Teste do alarme")
                startAlarm(listOf(AlertEngine.testAlert(System.currentTimeMillis())))
            }
            ACTION_TEST_NOTIFICATION -> {
                ensureForeground("Teste de notificação")
                val a = AlertEngine.testAlert(System.currentTimeMillis())
                Notifier.postAlert(this, a, ringing = false)
                if (!settings.monitoringEnabled && !player.isPlaying) {
                    stopForegroundSafely()
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            ACTION_START, ACTION_CHECK -> {
                if (action == ACTION_START) {
                    settings.monitoringEnabled = true
                }
                AppState.monitoring.value = true
                ensureForeground("A iniciar monitorização…")
                if (settings.monitorGps) tracker.start() else tracker.stop()
                launchCheck()
            }
        }
        return if (settings.monitoringEnabled) START_STICKY else START_NOT_STICKY
    }

    // ---------------------------------------------------------------- primeiro plano

    private fun ensureForeground(text: String) {
        val n = Notifier.monitorNotification(this, text)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (LocationTracker.hasPermission(this)) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                startForeground(Notifier.MONITOR_ID, n, type)
            } else if (Build.VERSION.SDK_INT >= 29) {
                val type = if (LocationTracker.hasPermission(this)) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
                startForeground(Notifier.MONITOR_ID, n, type)
            } else {
                startForeground(Notifier.MONITOR_ID, n)
            }
            foregroundOn = true
        } catch (e: Exception) {
            // O sistema pode recusar (ex.: arranque em segundo plano sem isenção de bateria). Segue sem primeiro plano.
            foregroundOn = false
        }
    }

    private fun stopForegroundSafely() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        foregroundOn = false
    }

    private fun updateMonitorNotification(text: String) {
        if (!foregroundOn) return
        getSystemService(android.app.NotificationManager::class.java)
            .notify(Notifier.MONITOR_ID, Notifier.monitorNotification(this, text))
    }

    // ---------------------------------------------------------------- verificações

    private fun onNewFix(fix: LocationFix) {
        AppState.lastFix.value = fix
        val prev = lastEvaluatedFix
        val moved = prev == null ||
            AlertEngine.haversineKm(prev.lat, prev.lon, fix.lat, fix.lon) >= 3.0
        // Reavalia ao mudar de sítio (≥ 3 km), no máximo 1 vez por minuto.
        if (moved && System.currentTimeMillis() - lastCheckAt > 60_000) launchCheck()
    }

    private fun launchCheck() {
        if (checkJob?.isActive == true) return
        checkJob = scope.launch { performCheck() }
    }

    private suspend fun performCheck() = mutex.withLock {
        val wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlertaTempestade:check")
        try {
            wl.acquire(90_000L)
            lastCheckAt = System.currentTimeMillis()
            val fix = if (settings.monitorGps) AppState.lastFix.value ?: LocationTracker.lastKnown(this) else null
            if (fix != null) {
                AppState.lastFix.value = fix
                lastEvaluatedFix = fix
            }
            val previous = AppState.places.value.associateBy { it.id }
            val result = Checker(settings).run(fix, previous)
            AppState.places.value = result

            val all = result.flatMap { it.alerts }.distinctBy { it.key }
            val notified = settings.notifiedKeys()
            val fresh = AlertEngine.fresh(all, notified)
            if (fresh.isNotEmpty()) {
                val horizon = fresh.maxOf { it.endsAt?.toEpochMilli() ?: (System.currentTimeMillis() + 6 * 3600_000L) }
                settings.markNotified(fresh.map { it.key }, horizon + 3600_000L)
                val ringers = fresh.filter { AlertEngine.shouldRing(it, settings.minAlarmLevel) }
                fresh.forEach { a ->
                    val ring = a in ringers
                    postedAlerts[a.key] = a
                    Notifier.postAlert(this, a, ringing = ring)
                }
                if (ringers.isNotEmpty()) startAlarm(ringers)
            }

            // Retira notificações de alertas que já terminaram (se o alarme não estiver a tocar por causa deles).
            val activeKeys = all.map { it.key }.toSet()
            val ringingKeys = AppState.alarm.value?.alerts?.map { it.key }?.toSet() ?: emptySet()
            postedAlerts.entries.removeAll { (k, a) ->
                val gone = k !in activeKeys && k !in ringingKeys
                if (gone) Notifier.cancel(this, a)
                gone
            }

            updateMonitorNotification(summaryText(result.size, all.size, result.any { it.stale }))
        } catch (e: Exception) {
            updateMonitorNotification("Erro na verificação; nova tentativa em breve.")
        } finally {
            if (wl.isHeld) wl.release()
            if (settings.monitoringEnabled) scheduleNextCheck()
        }
    }

    private fun summaryText(places: Int, alerts: Int, stale: Boolean): String {
        val hour = DateTimeFormatter.ofPattern("HH:mm").withZone(IpmaParser.LISBON).format(Instant.now())
        val what = when {
            alerts > 0 -> "$alerts alerta(s) ativo(s)"
            else -> "Sem alertas ativos"
        }
        val warn = if (stale) " · SEM LIGAÇÃO (dados desatualizados)" else ""
        return "$what · $places localização(ões) · verificado às $hour$warn"
    }

    // ---------------------------------------------------------------- alarme

    private fun startAlarm(alerts: List<AlertItem>) {
        val current = AppState.alarm.value
        val merged = ((current?.alerts ?: emptyList()) + alerts).distinctBy { it.key }
        AppState.alarm.value = AlarmInfo(merged, merged.all { it.key.startsWith("test|") })
        if (!player.isPlaying) player.start(settings.alarmSoundUri, settings.alarmVolume)
        // Garante que cada alerta que está a tocar tem notificação de emergência com DESLIGAR.
        alerts.forEach { Notifier.postAlert(this, it, ringing = true) }
    }

    private fun stopAlarmInternal() {
        player.stop()
        val info = AppState.alarm.value
        AppState.alarm.value = null
        // As notificações passam a informativas (ficam visíveis, mas sem tocar). O alarme só volta com alerta novo.
        info?.alerts?.forEach { Notifier.postAlert(this, it, ringing = false) }
    }

    // ---------------------------------------------------------------- agendamento

    private fun checkIntent(): PendingIntent =
        PendingIntent.getBroadcast(
            this, 0, Intent(this, CheckReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun scheduleNextCheck() {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = System.currentTimeMillis() + settings.intervalMin * 60_000L
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, checkIntent())
        } catch (e: Exception) { /* ignorar */ }
    }

    private fun cancelNextCheck() {
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(checkIntent())
    }

    override fun onDestroy() {
        tracker.stop()
        player.stop()
        scope.cancel()
        super.onDestroy()
    }
}
