package pt.alertatempestade.data

import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.Instant
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZoneOffset

/** Funções puras de leitura dos ficheiros JSON do IPMA (testáveis sem Android). */
object IpmaParser {
    val LISBON: ZoneId = ZoneId.of("Europe/Lisbon")

    fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

    /** Hora dos avisos: hora local de Lisboa, sem fuso (ex.: 2026-11-11T09:00:00). */
    fun parseLocalTime(s: String?): Instant? {
        if (s.isNullOrBlank()) return null
        val t = s.trim()
        return try {
            when {
                t.endsWith("Z") -> Instant.parse(t)
                t.length > 19 && (t[19] == '+' || t[19] == '-') -> OffsetDateTime.parse(t).toInstant()
                else -> LocalDateTime.parse(t.take(19)).atZone(LISBON).toInstant()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Hora das observações: UTC (ex.: 2026-11-11T07:00). */
    fun parseUtcTime(s: String?): Instant? {
        if (s.isNullOrBlank()) return null
        return try {
            LocalDateTime.parse(s.trim().take(19)).toInstant(ZoneOffset.UTC)
        } catch (e: Exception) {
            null
        }
    }

    fun classify(typeName: String): WarnType {
        val n = normalize(typeName)
        return when {
            n.contains("trovoada") -> WarnType.THUNDER
            n.contains("vento") -> WarnType.WIND
            n.contains("precipita") || n.contains("chuva") -> WarnType.RAIN
            else -> WarnType.OTHER
        }
    }

    fun parseWarnings(json: String): List<Warning> {
        val arr = JSONArray(json)
        val out = ArrayList<Warning>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val level = Level.fromIpma(o.optString("awarenessLevelID"))
            val start = parseLocalTime(o.optString("startTime")) ?: continue
            val end = parseLocalTime(o.optString("endTime")) ?: continue
            val typeName = o.optString("awarenessTypeName").ifBlank { "Aviso" }
            out += Warning(
                areaId = o.optString("idAreaAviso"),
                typeName = typeName,
                type = classify(typeName),
                level = level,
                start = start,
                end = end,
                text = o.optString("text").trim()
            )
        }
        return out
    }

    private val AREA_CODE_BY_NAME = mapOf(
        "aveiro" to "AVR", "beja" to "BJA", "braga" to "BRG", "braganca" to "BGC",
        "castelo branco" to "CBO", "coimbra" to "CBR", "evora" to "EVR", "faro" to "FAR",
        "guarda" to "GDA", "leiria" to "LRA", "lisboa" to "LSB", "portalegre" to "PTG",
        "porto" to "PTO", "santarem" to "STM", "setubal" to "STB",
        "viana do castelo" to "VCT", "vila real" to "VRL", "viseu" to "VIS"
    )

    fun parseAreas(json: String): List<Area> {
        val data = JSONObject(json).getJSONArray("data")
        val out = ArrayList<Area>()
        for (i in 0 until data.length()) {
            val o = data.optJSONObject(i) ?: continue
            val name = o.optString("local")
            val lat = o.optString("latitude").toDoubleOrNull() ?: continue
            val lon = o.optString("longitude").toDoubleOrNull() ?: continue
            val gid = o.optInt("globalIdLocal", -1)
            val code = o.optString("idAreaAviso").ifBlank { AREA_CODE_BY_NAME[normalize(name)] ?: "" }
            if (name.isBlank() || code.isBlank()) continue
            out += Area(gid, code, name, lat, lon)
        }
        return out
    }

    fun parseWeatherTypes(json: String): Map<Int, String> {
        val data = JSONObject(json).getJSONArray("data")
        val out = HashMap<Int, String>()
        for (i in 0 until data.length()) {
            val o = data.optJSONObject(i) ?: continue
            out[o.optInt("idWeatherType")] = o.optString("descWeatherTypePT")
        }
        return out
    }

    private fun JSONObject.str(name: String): String? =
        if (has(name) && !isNull(name)) optString(name).ifBlank { null } else null

    fun parseForecast(json: String, today: String): DailyForecast? {
        val data = JSONObject(json).getJSONArray("data")
        var pick: JSONObject? = null
        for (i in 0 until data.length()) {
            val o = data.optJSONObject(i) ?: continue
            if (o.optString("forecastDate") == today) { pick = o; break }
            if (pick == null) pick = o
        }
        val o = pick ?: return null
        return DailyForecast(
            date = o.optString("forecastDate"),
            tMin = o.str("tMin"),
            tMax = o.str("tMax"),
            precipProb = o.str("precipitaProb"),
            windDir = o.str("predWindDir"),
            windClass = o.str("classWindSpeed")?.toIntOrNull(),
            weatherTypeId = o.str("idWeatherType")?.toIntOrNull()
        )
    }

    fun parseStations(json: String): List<Station> {
        val arr = JSONArray(json)
        val out = ArrayList<Station>()
        for (i in 0 until arr.length()) {
            val f = arr.optJSONObject(i) ?: continue
            val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
            val props = f.optJSONObject("properties") ?: continue
            if (coords.length() < 2) continue
            val id = props.opt("idEstacao")?.toString() ?: continue
            out += Station(id, props.optString("localEstacao", id), coords.getDouble(1), coords.getDouble(0))
        }
        return out
    }

    private fun JSONObject.valid(name: String): Double? {
        val v = optDouble(name, Double.NaN)
        return if (v.isNaN() || v <= -90.0) null else v
    }

    /** Última observação válida de cada estação: id -> observação. */
    fun parseLatestObservations(json: String): Map<String, RawObservation> {
        val root = JSONObject(json)
        val times = root.keys().asSequence().toList().sortedDescending()
        val out = HashMap<String, RawObservation>()
        for (key in times) {
            val time = parseUtcTime(key) ?: continue
            val stations = root.optJSONObject(key) ?: continue
            for (id in stations.keys()) {
                if (out.containsKey(id)) continue
                val o = stations.optJSONObject(id) ?: continue
                var wind = o.valid("intensidadeVentoKM")
                if (wind == null) wind = o.valid("intensidadeVento")?.let { it * 3.6 }
                val temp = o.valid("temperatura")
                val hum = o.valid("humidade")
                if (wind == null && temp == null && hum == null) continue
                out[id] = RawObservation(time, temp, wind, hum)
            }
        }
        return out
    }
}
