package pt.alertatempestade

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import pt.alertatempestade.data.AppSettings
import pt.alertatempestade.data.AppState
import pt.alertatempestade.ui.AppTheme
import pt.alertatempestade.ui.HelpScreen
import pt.alertatempestade.ui.HomeScreen
import pt.alertatempestade.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_ALARM = "alarm"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyAlarmFlags(intent)
        enableEdgeToEdge()
        AppState.monitoring.value = AppSettings(this).monitoringEnabled
        setContent {
            AppTheme { AppRoot() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyAlarmFlags(intent)
    }

    /** Se aberta a partir do alarme: aparece por cima do ecrã de bloqueio e liga o ecrã. */
    private fun applyAlarmFlags(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_ALARM, false) == true) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text("Alertas") }
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    label = { Text("Definições") }
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Filled.Info, contentDescription = null) },
                    label = { Text("Ajuda") }
                )
            }
        }
    ) { pad: PaddingValues ->
        when (tab) {
            0 -> HomeScreen(pad)
            1 -> SettingsScreen(pad)
            else -> HelpScreen(pad)
        }
    }
}
