package pt.alertatempestade.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HelpScreen(pad: PaddingValues) {
    Column(
        modifier = Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Ajuda", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        H("Como funciona")
        P("A aplicação consulta os avisos oficiais do IPMA (trovoada, vento, chuva) para a zona do Porto e/ou da sua posição. " +
            "Quando surge um aviso amarelo, laranja ou vermelho NOVO, toca um alarme e mostra uma notificação com o motivo. " +
            "O alarme repete-se até carregar em DESLIGAR. Desligar o alarme não desativa a monitorização.")
        P("Previsões (por exemplo, probabilidade de chuva) NÃO são avisos oficiais e nunca fazem tocar o alarme.")
        P("Raios: o IPMA não disponibiliza dados abertos de descargas em tempo real; a possibilidade de raios é indicada pelos avisos oficiais de trovoada.")

        H("RedMagic (Redmagic OS) — evitar que o sistema pare a monitorização")
        P("1. Definições › Aplicações › Gestão de aplicações › Alerta Tempestade Portugal › Uso de bateria: escolha «Sem restrições» (ou «Permitir atividade em segundo plano»).")
        P("2. Ainda nas informações da aplicação: ative «Arranque automático» / «Início automático».")
        P("3. Abra os Recentes, mantenha o dedo sobre o cartão da aplicação e escolha o ícone do cadeado (bloquear) para não ser fechada ao «Limpar tudo».")
        P("4. Centro de jogos / Game Space: não use o modo que limita aplicações em segundo plano para esta aplicação. Se usar «Modo de poupança de bateria», exclua a aplicação.")
        P("5. Definições › Notificações: permita todas as notificações e o canal «Alertas meteorológicos» com importância Alta; ative «Ecrã de bloqueio» e «Ecrã inteiro/Pop-up» se existirem.")
        P("6. Localização: «Permitir sempre» + «Localização precisa». Sem isto o GPS não funciona com o ecrã bloqueado.")
        P("7. Volume: o alarme usa o volume de «Alarme» do telemóvel (definido em Definições › Volume). Não ponha o modo «Não incomodar» em silêncio total.")
        P("Os nomes exatos dos menus variam com a versão do Redmagic OS; se não encontrar um, procure «bateria», «arranque automático» ou «aplicações em segundo plano».")

        H("Privacidade")
        P("A sua posição GPS fica apenas neste telemóvel e nunca é enviada a ninguém. A aplicação só descarrega ficheiros públicos do IPMA (api.ipma.pt) e compara a zona no próprio telemóvel. " +
            "Não há contas, publicidade nem estatísticas. As cópias de segurança do Android estão desativadas para esta aplicação.")

        H("Limitações")
        P("Dependente da Internet e dos dados do IPMA: se não houver ligação, a aplicação diz-o e marca os dados como desatualizados. " +
            "Esta aplicação é um auxílio e não substitui os canais oficiais (IPMA, Proteção Civil, 112). Não a manuseie enquanto conduz.")
    }
}

@Composable
private fun H(t: String) = Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

@Composable
private fun P(t: String) = Text(t, style = MaterialTheme.typography.bodyMedium)
