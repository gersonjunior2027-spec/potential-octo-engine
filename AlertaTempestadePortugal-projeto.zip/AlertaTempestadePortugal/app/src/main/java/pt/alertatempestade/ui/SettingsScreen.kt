package pt.alertatempestade.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import pt.alertatempestade.data.AppSettings
import pt.alertatempestade.data.AppState
import pt.alertatempestade.service.MonitorService
import kotlin.math.roundToInt

private fun soundTitle(ctx: Context, uri: String): String {
    if (uri.isBlank()) return "Toque de chamada predefinido do telemóvel"
    return try {
        RingtoneManager.getRingtone(ctx, Uri.parse(uri))?.getTitle(ctx) ?: "Som personalizado"
    } catch (e: Exception) {
        "Som personalizado"
    }
}

@Composable
fun SettingsScreen(pad: PaddingValues) {
    val ctx = LocalContext.current
    val s = remember { AppSettings(ctx) }

    var porto by remember { mutableStateOf(s.monitorPorto) }
    var gps by remember { mutableStateOf(s.monitorGps) }
    var volume by remember { mutableIntStateOf(s.alarmVolume) }
    var sound by remember { mutableStateOf(s.alarmSoundUri) }
    var minLevel by remember { mutableIntStateOf(s.minAlarmLevel) }
    var windOn by remember { mutableStateOf(s.windAlertEnabled) }
    var windKmh by remember { mutableIntStateOf(s.windThresholdKmh) }
    var interval by remember { mutableIntStateOf(s.intervalMin) }

    fun applyNow() {
        if (AppState.monitoring.value) MonitorService.requestCheck(ctx)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val data = r.data
            val uri = if (data == null) null else
                IntentCompat.getParcelableExtra(data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            sound = uri?.toString() ?: ""
            s.alarmSoundUri = sound
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Definições", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Section("Localizações a monitorizar") {
            SwitchRow("Porto (localização fixa)", porto) { porto = it; s.monitorPorto = it; applyNow() }
            SwitchRow("A minha localização (GPS, atualiza em movimento)", gps) { gps = it; s.monitorGps = it; applyNow() }
        }

        Section("Alarme") {
            Text("Som do alarme: ${soundTitle(ctx, sound)}", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_ALARM)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Som do alarme")
                    if (sound.isNotBlank()) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(sound))
                    picker.launch(i)
                }) { Text("Escolher som") }
                OutlinedButton(onClick = { sound = ""; s.alarmSoundUri = "" }) { Text("Usar toque predefinido") }
            }
            Text("Volume do alerta: $volume%")
            Slider(
                value = volume.toFloat(),
                onValueChange = { volume = it.roundToInt() },
                onValueChangeFinished = { s.alarmVolume = volume },
                valueRange = 10f..100f
            )
            Text("Tocar o alarme a partir do nível:")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1 to "Amarelo", 2 to "Laranja", 3 to "Vermelho").forEach { (rank, label) ->
                    FilterChip(selected = minLevel == rank, onClick = { minLevel = rank; s.minAlarmLevel = rank }, label = { Text(label) })
                }
            }
            Text(
                "Abaixo deste nível recebe só a notificação, sem som. O alarme só toca uma vez por alerta novo.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Section("Vento (alerta adicional definido por si)") {
            SwitchRow("Alertar quando o vento medido ultrapassar o limite", windOn) { windOn = it; s.windAlertEnabled = it; applyNow() }
            Text("Limite: $windKmh km/h")
            Slider(
                value = windKmh.toFloat(),
                onValueChange = { windKmh = it.roundToInt() },
                onValueChangeFinished = { s.windThresholdKmh = windKmh; applyNow() },
                valueRange = 30f..130f,
                enabled = windOn
            )
            Text(
                "Usa a medição da estação meteorológica do IPMA mais próxima (a menos de 60 km). " +
                    "Não é um aviso oficial; aparece identificado como «Vento medido».",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Section("Frequência de atualização") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15, 30).forEach { m ->
                    FilterChip(selected = interval == m, onClick = { interval = m; s.intervalMin = m; applyNow() }, label = { Text("$m min") })
                }
            }
            Text(
                "Mais frequente = respostas mais rápidas, mas mais bateria e dados. " +
                    "Com o ecrã apagado o Android pode atrasar um pouco as verificações.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Section("Testes") {
            Button(onClick = { MonitorService.testAlarm(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("Testar alarme (toca até carregar em DESLIGAR)")
            }
            OutlinedButton(onClick = { MonitorService.testNotification(ctx) }, modifier = Modifier.fillMaxWidth()) {
                Text("Testar só a notificação (sem som)")
            }
            Text(
                "Para testar com o ecrã bloqueado: carregue em «Testar alarme» e bloqueie o telemóvel de imediato.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
