package pt.alertatempestade.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Cliente da API aberta oficial do IPMA (https://api.ipma.pt/open-data). Só descarrega ficheiros públicos. */
object IpmaApi {
    private const val BASE = "https://api.ipma.pt/open-data"

    @Throws(IOException::class)
    private fun get(path: String): String {
        val c = URL("$BASE/$path").openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 25_000
        c.setRequestProperty("Accept", "application/json")
        c.setRequestProperty("User-Agent", "AlertaTempestadePortugal/1.0 (Android)")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun warnings(): List<Warning> =
        IpmaParser.parseWarnings(get("forecast/warnings/warnings_www.json"))

    fun areas(): List<Area> =
        IpmaParser.parseAreas(get("distrits-islands.json"))

    fun weatherTypes(): Map<Int, String> =
        IpmaParser.parseWeatherTypes(get("weather-type-classe.json"))

    fun dailyForecast(globalIdLocal: Int, today: String): DailyForecast? =
        IpmaParser.parseForecast(get("forecast/meteorology/cities/daily/$globalIdLocal.json"), today)

    fun stations(): List<Station> =
        IpmaParser.parseStations(get("observation/meteorology/stations/stations.json"))

    fun latestObservations(): Map<String, RawObservation> =
        IpmaParser.parseLatestObservations(get("observation/meteorology/stations/observations.json"))
}
