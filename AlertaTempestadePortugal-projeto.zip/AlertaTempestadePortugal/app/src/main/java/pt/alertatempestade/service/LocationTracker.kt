package pt.alertatempestade.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import pt.alertatempestade.data.LocationFix

/** Localização GPS do Android (sem Google Play Services). A posição fica só no telemóvel. */
class LocationTracker(
    private val ctx: Context,
    private val onFix: (LocationFix) -> Unit
) : LocationListener {

    private val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var running = false

    companion object {
        fun hasPermission(ctx: Context): Boolean =
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        @SuppressLint("MissingPermission")
        fun lastKnown(ctx: Context): LocationFix? {
            if (!hasPermission(ctx)) return null
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                val l = try { lm.getLastKnownLocation(prov) } catch (e: Exception) { null } ?: continue
                if (best == null || l.time > best.time) best = l
            }
            return best?.let { LocationFix(it.latitude, it.longitude, it.time) }
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (running || !hasPermission(ctx)) return
        try {
            // Atualiza a cada 30 s ou 300 m, o que ocorrer primeiro; suficiente para conduzir sem gastar bateria em excesso.
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30_000L, 300f, this, Looper.getMainLooper())
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60_000L, 500f, this, Looper.getMainLooper())
            }
            running = true
        } catch (e: Exception) {
            running = false
        }
    }

    fun stop() {
        if (!running) return
        try { lm.removeUpdates(this) } catch (e: Exception) { /* ignorar */ }
        running = false
    }

    override fun onLocationChanged(location: Location) {
        onFix(LocationFix(location.latitude, location.longitude, location.time))
    }

    @Deprecated("Necessário em versões antigas do Android")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}
