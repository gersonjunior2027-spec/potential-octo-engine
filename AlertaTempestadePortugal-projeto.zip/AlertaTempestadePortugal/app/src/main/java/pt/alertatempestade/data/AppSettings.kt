package pt.alertatempestade.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

/** Definições e memória de alertas já notificados. Tudo guardado só neste telemóvel. */
class AppSettings(ctx: Context) {
    private val p: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var monitorPorto: Boolean
        get() = p.getBoolean("monitorPorto", true)
        set(v) = p.edit().putBoolean("monitorPorto", v).apply()

    var monitorGps: Boolean
        get() = p.getBoolean("monitorGps", true)
        set(v) = p.edit().putBoolean("monitorGps", v).apply()

    /** 10..100 (% do volume do alarme do sistema). */
    var alarmVolume: Int
        get() = p.getInt("alarmVolume", 90)
        set(v) = p.edit().putInt("alarmVolume", v.coerceIn(10, 100)).apply()

    /** Vazio = toque de chamada predefinido do telemóvel. */
    var alarmSoundUri: String
        get() = p.getString("alarmSoundUri", "") ?: ""
        set(v) = p.edit().putString("alarmSoundUri", v).apply()

    /** Nível mínimo (1 amarelo, 2 laranja, 3 vermelho) que faz tocar o alarme. */
    var minAlarmLevel: Int
        get() = p.getInt("minAlarmLevel", 1)
        set(v) = p.edit().putInt("minAlarmLevel", v.coerceIn(1, 3)).apply()

    var windAlertEnabled: Boolean
        get() = p.getBoolean("windAlertEnabled", true)
        set(v) = p.edit().putBoolean("windAlertEnabled", v).apply()

    var windThresholdKmh: Int
        get() = p.getInt("windThresholdKmh", 60)
        set(v) = p.edit().putInt("windThresholdKmh", v.coerceIn(30, 130)).apply()

    var intervalMin: Int
        get() = p.getInt("intervalMin", 10)
        set(v) = p.edit().putInt("intervalMin", v.coerceIn(5, 60)).apply()

    /** Estado desejado da monitorização (para retomar após reiniciar o telemóvel). */
    var monitoringEnabled: Boolean
        get() = p.getBoolean("monitoringEnabled", false)
        set(v) = p.edit().putBoolean("monitoringEnabled", v).apply()

    /** Chaves de alertas já notificados -> instante (ms) em que podem ser esquecidas. */
    fun notifiedKeys(nowMillis: Long = System.currentTimeMillis()): Set<String> {
        val o = readNotified()
        return o.keys().asSequence().filter { o.optLong(it) > nowMillis }.toSet()
    }

    fun markNotified(keys: Collection<String>, expiresAtMillis: Long) {
        val now = System.currentTimeMillis()
        val o = readNotified()
        val it = o.keys()
        val dead = ArrayList<String>()
        while (it.hasNext()) {
            val k = it.next()
            if (o.optLong(k) <= now) dead += k
        }
        dead.forEach { o.remove(it) }
        keys.forEach { o.put(it, expiresAtMillis) }
        p.edit().putString("notified", o.toString()).apply()
    }

    private fun readNotified(): JSONObject =
        try { JSONObject(p.getString("notified", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
}
