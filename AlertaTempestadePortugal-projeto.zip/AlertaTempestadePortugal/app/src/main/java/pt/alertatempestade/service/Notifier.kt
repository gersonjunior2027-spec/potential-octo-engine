package pt.alertatempestade.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import pt.alertatempestade.MainActivity
import pt.alertatempestade.R
import pt.alertatempestade.data.AlertItem
import pt.alertatempestade.data.Level

object Notifier {
    const val CH_MONITOR = "monitor"
    const val CH_ALERT = "alertas_v1"
    const val MONITOR_ID = 1001

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Monitorização em curso", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Notificação permanente enquanto a monitorização está ativa."
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Alertas meteorológicos", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alertas de tempestade, vento forte e chuva intensa."
                setSound(null, null) // o som é tocado pelo alarme da aplicação até carregar em DESLIGAR
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun openApp(ctx: Context, code: Int, alarm: Boolean): PendingIntent =
        PendingIntent.getActivity(
            ctx, code,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(MainActivity.EXTRA_ALARM, alarm),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun monitorNotification(ctx: Context, text: String): Notification =
        NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle("Alerta Tempestade Portugal")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(openApp(ctx, 1, false))
            .build()

    fun idFor(a: AlertItem): Int = 2000 + (a.key.hashCode() and 0x0FFFFFFF) % 100000

    private fun color(l: Level): Int = when (l) {
        Level.RED -> 0xFFC62828.toInt()
        Level.ORANGE -> 0xFFEF6C00.toInt()
        else -> 0xFFF9A825.toInt()
    }

    /** ringing = true: notificação de emergência com botão DESLIGAR; false: apenas informativa. */
    fun postAlert(ctx: Context, a: AlertItem, ringing: Boolean) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val b = NotificationCompat.Builder(ctx, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat_alert)
            .setContentTitle(a.title)
            .setContentText(a.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText("${a.body}\n${a.detail}"))
            .setColor(color(a.level))
            .setColorized(false)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openApp(ctx, 2, false))
            .setOnlyAlertOnce(!ringing)
        if (ringing) {
            b.setOngoing(true)
            b.setAutoCancel(false)
            b.setFullScreenIntent(openApp(ctx, 3, true), true)
            b.addAction(
                0, "DESLIGAR",
                PendingIntent.getService(
                    ctx, 4,
                    Intent(ctx, MonitorService::class.java).setAction(MonitorService.ACTION_STOP_ALARM),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        } else {
            b.setOngoing(false)
            b.setAutoCancel(true)
            b.setSilent(true)
        }
        nm.notify(idFor(a), b.build())
    }

    fun cancel(ctx: Context, a: AlertItem) {
        ctx.getSystemService(NotificationManager::class.java).cancel(idFor(a))
    }
}
