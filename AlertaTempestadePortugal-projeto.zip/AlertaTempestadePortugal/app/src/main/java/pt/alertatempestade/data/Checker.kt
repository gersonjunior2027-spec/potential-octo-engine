package pt.alertatempestade.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.time.Instant
import java.time.LocalDate

/**
 * Descarrega os dados oficiais do IPMA e calcula o estado de cada localização.
 * A posição GPS NUNCA é enviada: só se descarregam ficheiros públicos e a comparação é feita no telemóvel.
 */
class Checker(private val settings: AppSettings) {

    private object Cache {
        @Volatile var areas: List<Area>? = null
        @Volatile var stations: List<Station>? = null
        @Volatile var stationsAt: Long = 0
        @Volatile var weatherTypes: Map<Int, String>? = null
    }

    private data class Place(val id: String, val label: String, val lat: Double?, val lon: Double?)

    companion object {
        const val PORTO_LAT = 41.1579
        const val PORTO_LON = -8.6291
        private val PORTO_AREA = Area(1131200, "PTO", "Porto", 41.1496, -8.6109)
        private const val MAX_DISTANCE_KM = 150.0

        /** Capitais de distrito (apenas para quando a lista online não carrega). */
        private val FALLBACK_AREAS = listOf(
            Area(1010500, "AVR", "Aveiro", 40.64, -8.65), Area(1020500, "BJA", "Beja", 38.02, -7.86),
            Area(1030300, "BRG", "Braga", 41.55, -8.42), Area(1040200, "BGC", "Bragança", 41.81, -6.76),
            Area(1050200, "CBO", "Castelo Branco", 39.82, -7.49), Area(1060300, "CBR", "Coimbra", 40.21, -8.43),
            Area(1070500, "EVR", "Évora", 38.57, -7.91), Area(1080500, "FAR", "Faro", 37.02, -7.93),
            Area(1090700, "GDA", "Guarda", 40.54, -7.27), Area(1100900, "LRA", "Leiria", 39.74, -8.81),
            Area(1110600, "LSB", "Lisboa", 38.72, -9.14), Area(1121400, "PTG", "Portalegre", 39.29, -7.43),
            PORTO_AREA, Area(1141600, "STM", "Santarém", 39.24, -8.69),
            Area(1151200, "STB", "Setúbal", 38.52, -8.89), Area(1160900, "VCT", "Viana do Castelo", 41.69, -8.83),
            Area(1171400, "VRL", "Vila Real", 41.30, -7.74), Area(1182300, "VIS", "Viseu", 40.66, -7.91)
        )

        fun describeError(e: Throwable): String = when (e) {
            is UnknownHostException, is ConnectException, is SocketTimeoutException ->
                "Sem ligação à Internet. Os dados abaixo podem estar desatualizados."
            else -> "Serviço do IPMA indisponível neste momento (${e.message ?: e.javaClass.simpleName})."
        }
    }

    suspend fun run(fix: LocationFix?, previous: Map<String, PlaceStatus>): List<PlaceStatus> =
        withContext(Dispatchers.IO) {
            val now = Instant.now()
            val places = ArrayList<Place>()
            if (settings.monitorPorto) places += Place("porto", "Porto", PORTO_LAT, PORTO_LON)
            if (settings.monitorGps) places += Place("gps", "A minha localização", fix?.lat, fix?.lon)
            if (places.isEmpty()) return@withContext emptyList()

            val warnings = runCatching { IpmaApi.warnings() }
            val areas = Cache.areas ?: runCatching { IpmaApi.areas() }.getOrNull()
                ?.takeIf { it.isNotEmpty() }?.also { Cache.areas = it }
            val wTypes = Cache.weatherTypes ?: runCatching { IpmaApi.weatherTypes() }.getOrNull()
                ?.also { Cache.weatherTypes = it }
            val stations = Cache.stations?.takeIf { now.toEpochMilli() - Cache.stationsAt < 7L * 24 * 3600 * 1000 }
                ?: runCatching { IpmaApi.stations() }.getOrNull()?.also {
                    Cache.stations = it; Cache.stationsAt = now.toEpochMilli()
                } ?: Cache.stations
            val observations = runCatching { IpmaApi.latestObservations() }.getOrNull()
            val today = LocalDate.now(IpmaParser.LISBON)

            places.map { p ->
                val prev = previous[p.id]
                if (p.lat == null || p.lon == null) {
                    return@map PlaceStatus(p.id, p.label, problem = "À espera da posição GPS… " +
                        "Verifique se a localização e a permissão estão ativas.")
                }
                val areaList = areas ?: FALLBACK_AREAS
                val area: Area
                var note: String? = null
                if (p.id == "porto") {
                    area = areaList.firstOrNull { it.areaId == "PTO" } ?: PORTO_AREA
                } else {
                    val (nearest, dist) = AlertEngine.nearestArea(areaList, p.lat, p.lon)
                        ?: return@map PlaceStatus(p.id, p.label, problem = "Zonas de aviso indisponíveis.")
                    if (dist > MAX_DISTANCE_KM) {
                        return@map PlaceStatus(
                            p.id, p.label, hasData = true, fetchedAt = now.toEpochMilli(),
                            note = "Fora da área de cobertura do IPMA (zona mais próxima: ${nearest.name}, a ${dist.toInt()} km)."
                        )
                    }
                    area = nearest
                    note = "Zona de aviso mais próxima: ${area.name} (a ${dist.toInt()} km)."
                }

                // Avisos oficiais (se o descarregamento falhar, mantém o último estado e marca-o como desatualizado)
                val official: List<AlertItem>
                val other: List<AlertItem>
                var problem: String? = null
                var fetchedAt = now.toEpochMilli()
                val stale: Boolean
                val w = warnings.getOrNull()
                if (w != null) {
                    val active = AlertEngine.activeWarnings(w, area.areaId, now).map { AlertEngine.fromWarning(it, area.name) }
                    official = active.filter { it.type.emergency }
                    other = active.filter { !it.type.emergency }
                    stale = false
                } else {
                    problem = describeError(warnings.exceptionOrNull() ?: Exception("?"))
                    official = AlertEngine.stillActive(prev?.alerts?.filter { it.source == AlertSource.OFFICIAL } ?: emptyList(), now)
                    other = AlertEngine.stillActive(prev?.otherWarnings ?: emptyList(), now)
                    fetchedAt = prev?.fetchedAt ?: 0L
                    stale = true
                }

                val forecast = runCatching { IpmaApi.dailyForecast(area.globalIdLocal, today.toString()) }.getOrNull()
                    ?: prev?.forecast
                val forecastDesc = forecast?.weatherTypeId?.let { wTypes?.get(it) } ?: prev?.forecastDesc

                val obs = if (stations != null && observations != null)
                    AlertEngine.nearestStation(stations, observations, p.lat, p.lon) else null
                val windAlert = if (settings.windAlertEnabled)
                    AlertEngine.windAlert(obs, settings.windThresholdKmh, now, today) else null

                PlaceStatus(
                    id = p.id,
                    label = p.label,
                    areaName = area.name,
                    areaId = area.areaId,
                    alerts = official + listOfNotNull(windAlert),
                    otherWarnings = other,
                    forecast = forecast,
                    forecastDesc = forecastDesc,
                    observation = obs,
                    fetchedAt = fetchedAt,
                    problem = problem,
                    stale = stale,
                    note = note,
                    hasData = w != null || prev?.hasData == true
                )
            }
        }
}
