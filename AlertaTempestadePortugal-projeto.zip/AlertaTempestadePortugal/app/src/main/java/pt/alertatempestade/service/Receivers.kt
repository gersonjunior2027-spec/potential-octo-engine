package pt.alertatempestade.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import pt.alertatempestade.data.AppSettings

/** Disparado pelo AlarmManager para a próxima verificação periódica. */
class CheckReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (AppSettings(context).monitoringEnabled) MonitorService.requestCheck(context)
    }
}

/** Retoma a monitorização depois de reiniciar o telemóvel ou atualizar a aplicação. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (AppSettings(context).monitoringEnabled) MonitorService.start(context)
        }
    }
}
