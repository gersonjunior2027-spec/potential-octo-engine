package pt.alertatempestade.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.roundToInt

/** Toca o alarme em ciclo (som de chamada + vibração) até ser chamado stop(). */
class AlarmPlayer(private val ctx: Context) {
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private var previousVolume = -1
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Suppress("DEPRECATION")
    private val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    val isPlaying: Boolean get() = player != null

    fun start(customUri: String, volumePercent: Int) {
        stop()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        // Volume: usa a percentagem escolhida do volume máximo do canal de alarme (restaurado ao desligar).
        try {
            previousVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, (max * volumePercent / 100f).roundToInt().coerceIn(1, max), 0)
        } catch (e: Exception) {
            previousVolume = -1
        }

        try {
            focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener { }
                .build()
            am.requestAudioFocus(focus!!)
        } catch (e: Exception) { /* continua sem foco */ }

        val candidates = ArrayList<Uri>()
        if (customUri.isNotBlank()) candidates += Uri.parse(customUri)
        RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE)?.let { candidates += it }
        RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_ALARM)?.let { candidates += it }
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let { candidates += it }

        for (uri in candidates) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(attrs)
                mp.setDataSource(ctx, uri)
                mp.isLooping = true
                mp.setVolume(1f, 1f)
                mp.prepare()
                mp.start()
                player = mp
                break
            } catch (e: Exception) {
                // tenta o som seguinte
            }
        }

        try {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
        } catch (e: Exception) { /* sem vibração */ }
    }

    fun stop() {
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        player = null
        try { vibrator.cancel() } catch (e: Exception) { }
        try { focus?.let { am.abandonAudioFocusRequest(it) } } catch (e: Exception) { }
        focus = null
        if (previousVolume >= 0) {
            try { am.setStreamVolume(AudioManager.STREAM_ALARM, previousVolume, 0) } catch (e: Exception) { }
            previousVolume = -1
        }
    }
}
