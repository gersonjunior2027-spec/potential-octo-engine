package pt.alertatempestade.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import pt.alertatempestade.data.Level

val YellowAlert = Color(0xFFF9A825)
val OrangeAlert = Color(0xFFEF6C00)
val RedAlert = Color(0xFFC62828)
val GreenOk = Color(0xFF2E7D32)

fun levelColor(l: Level): Color = when (l) {
    Level.RED -> RedAlert
    Level.ORANGE -> OrangeAlert
    Level.YELLOW -> YellowAlert
    Level.GREEN -> GreenOk
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(primary = Color(0xFF90CAF9), error = Color(0xFFEF5350))
    } else {
        lightColorScheme(primary = Color(0xFF0D47A1), error = RedAlert)
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
