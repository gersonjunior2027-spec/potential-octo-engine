package pt.alertatempestade.data

import kotlinx.coroutines.flow.MutableStateFlow

/** Estado partilhado entre o serviço e a interface (apenas em memória). */
object AppState {
    val places = MutableStateFlow<List<PlaceStatus>>(emptyList())
    val alarm = MutableStateFlow<AlarmInfo?>(null)
    val monitoring = MutableStateFlow(false)
    val refreshing = MutableStateFlow(false)
    val lastFix = MutableStateFlow<LocationFix?>(null)
}
