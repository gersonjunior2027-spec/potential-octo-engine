# Sem regras específicas: minificação desativada nesta versão.
