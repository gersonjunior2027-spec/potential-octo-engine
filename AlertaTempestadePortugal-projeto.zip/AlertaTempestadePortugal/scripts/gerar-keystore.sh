#!/usr/bin/env bash
# Cria a chave de assinatura (keystore) para o APK de Release e o ficheiro keystore.properties.
# Guarde uma cópia do ficheiro .jks e da palavra-passe: sem eles não consegue atualizar a app instalada.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -f alerta-release.jks ]; then
  echo "alerta-release.jks já existe. Apague-o primeiro se quiser criar outro."; exit 1
fi

read -r -s -p "Escolha uma palavra-passe (mín. 6 caracteres): " PASS; echo
keytool -genkeypair -v -keystore alerta-release.jks -alias alerta -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=Alerta Tempestade Portugal, O=Pessoal, C=PT"

cat > keystore.properties <<EOF
storeFile=alerta-release.jks
storePassword=$PASS
keyAlias=alerta
keyPassword=$PASS
EOF
echo "Feito. Agora execute: ./gradlew assembleRelease"
echo "APK assinado em: app/build/outputs/apk/release/app-release.apk"
