# Alerta Tempestade Portugal

Aplicação Android (Kotlin + Jetpack Compose) que monitoriza os **avisos oficiais do IPMA** para o **Porto** e para a **sua localização GPS**, e toca um **alarme de emergência** (som de chamada, repetido até carregar em DESLIGAR) quando surge um aviso amarelo, laranja ou vermelho de trovoada, vento ou chuva intensa.

## Estado desta entrega (leia primeiro)

- O código-fonte está **completo**, mas **ainda não foi compilado nem testado num telemóvel**: o ambiente onde foi escrito não tem Android SDK nem acesso à rede para o instalar. Por isso **não existe APK nesta entrega**. Não o inventei: um APK só existe depois de compilar.
- Pode obter o APK assinado **sem programar** de duas formas (abaixo). Se a compilação mostrar algum erro, envie-me o texto do erro e corrijo.
- Os testes unitários (`app/src/test`) cobrem a lógica dos alertas e a leitura dos ficheiros do IPMA, mas ainda não foram executados.

## Obter o APK

### Opção A — Android Studio (mais simples)
1. Instale o Android Studio e abra a pasta `AlertaTempestadePortugal` (File › Open). Aguarde o «Gradle sync».
2. **Build › Generate Signed App Bundle / APK › APK › Create new…** para criar a sua chave, e escolha a variante **release**.
3. O ficheiro fica em `app/build/outputs/apk/release/app-release.apk`. (APK de teste sem assinatura própria: **Build › Build APK(s)**, variante debug.)

### Opção B — linha de comandos
```
./scripts/gerar-keystore.sh      # cria a chave e o keystore.properties (guarde o .jks e a palavra-passe!)
./gradlew testDebugUnitTest      # corre os testes da lógica dos alertas
./gradlew assembleRelease        # APK assinado: app/build/outputs/apk/release/app-release.apk
```
Requer JDK 17 e Android SDK 35 (`ANDROID_HOME`).

### Opção C — GitHub (sem instalar nada)
Crie um repositório privado, carregue esta pasta e abra **Actions › Compilar APK › Run workflow**. Ao fim de uns minutos descarregue o APK em *Artifacts*. Para poder **atualizar** a app no futuro sem desinstalar, defina os *secrets* `KEYSTORE_BASE64` (o `.jks` em base64) e `KEYSTORE_PASSWORD`; sem eles cada compilação usa uma chave nova.

## Instalar no telemóvel
1. Copie o `.apk` para o telemóvel (cabo, Drive, e-mail).
2. Abra-o; se pedir, permita «Instalar apps desconhecidas» para a aplicação que o abriu (Ficheiros/Chrome).
3. Abra **Alerta Tempestade Portugal**, toque em **Iniciar monitorização** e conceda as permissões pedidas no cartão vermelho (notificações, localização «Permitir sempre», sem restrições de bateria, ecrã inteiro).
4. Siga o guia do RedMagic (abaixo ou separador **Ajuda** na app) e faça os testes.

## Configurar o RedMagic (Redmagic OS)
Os nomes dos menus variam com a versão; procure «bateria», «arranque automático», «aplicações em segundo plano».
1. **Bateria**: Definições › Aplicações › Gestão de aplicações › Alerta Tempestade Portugal › Bateria → «Sem restrições».
2. **Arranque automático**: ativar para esta aplicação (necessário para retomar após reiniciar).
3. **Bloquear nos Recentes**: abra os Recentes, mantenha o dedo no cartão da app e toque no cadeado, para não ser fechada em «Limpar tudo».
4. **Game Space / modos de desempenho ou poupança**: excluir a aplicação de qualquer limitação em segundo plano.
5. **Notificações**: permitir tudo; canal «Alertas meteorológicos» com importância Alta; ativar ecrã de bloqueio e ecrã inteiro/pop-up.
6. **Localização**: «Permitir sempre» e «Localização precisa».
7. **Som**: o alarme usa o volume de *Alarme* do telemóvel. Não use «Não incomodar» em silêncio total.

## Como funciona
| Pedido | Implementação |
|---|---|
| Fonte oficial | API aberta do IPMA (`api.ipma.pt/open-data`): avisos (`warnings_www.json`), zonas (`distrits-islands.json`), previsão diária, estações e observações |
| Níveis | Amarelo, laranja e vermelho. Verde é ignorado |
| Avisos ≠ previsões | Só os **avisos oficiais** de Trovoada, Vento e Precipitação fazem tocar o alarme. A previsão aparece à parte, identificada como «não é um aviso oficial» |
| Raios | O IPMA não tem dados abertos de descargas em tempo real: a possibilidade de raios vem do aviso oficial de trovoada |
| Vento/rajadas | Aviso oficial de Vento + alerta opcional por **vento medido** (estação do IPMA a menos de 60 km), com limite em km/h definido por si e sempre identificado como «Vento medido» |
| Alarme | `MonitorService` (serviço em primeiro plano) toca o toque de chamada em ciclo (canal de alarme) + vibração, até **DESLIGAR** (botão na notificação ou na app) |
| Não repetir | Cada alerta (zona + tipo + nível + validade) só dispara uma vez. Só volta a tocar com um alerta novo ou com subida de nível |
| Segundo plano | Serviço em primeiro plano + `AlarmManager` (`setAndAllowWhileIdle`) para a verificação seguinte + `BOOT_COMPLETED` |
| GPS | `LocationManager` (sem Google Play Services), 30 s / 300 m; reavalia ao mudar ≥ 3 km |
| Sem Internet | Mostra «Sem ligação» e marca «DADOS DESATUALIZADOS» com a hora da última atualização |
| Privacidade | Posição só no telemóvel; apenas se descarregam ficheiros públicos; sem contas, publicidade ou estatísticas; backup desativado |

## Limitações e coisas a confirmar
- **Aviso por distrito**: o IPMA publica avisos por zona (distrito/ilha). A posição GPS é associada à capital de distrito mais próxima (até 150 km). Perto de limites de distrito pode haver diferenças.
- **Campos da API não verificados em direto**: o formato dos ficheiros `distrits-islands.json`, estações e observações foi escrito de memória e tem leitura tolerante a falhas. Se algum falhar, os avisos oficiais continuam a funcionar e a app indica a falha em vez de mostrar dados errados. Confirme no primeiro uso se aparece «Medido agora» e a previsão.
- **Android pode atrasar** verificações com o ecrã apagado e o telemóvel parado (Doze). A isenção de bateria e as definições do RedMagic reduzem isto, mas não existe garantia absoluta.
- **Ecrã inteiro** com o telemóvel bloqueado exige a permissão especial «Notificações em ecrã inteiro» (Android 14+).
- Esta aplicação é um auxílio e **não substitui** os canais oficiais (IPMA, Proteção Civil, 112). Não a manuseie a conduzir.

## Estrutura
```
app/src/main/java/pt/alertatempestade/
  MainActivity.kt                 # navegação (Alertas / Definições / Ajuda)
  data/    Models, IpmaApi, IpmaParser, AlertEngine, Checker, AppSettings, AppState
  service/ MonitorService, AlarmPlayer, Notifier, LocationTracker, Receivers
  ui/      HomeScreen, SettingsScreen, HelpScreen, Theme
app/src/test/.../AlertEngineTest.kt   # testes da lógica
```
Ver `TESTES.md` para a lista de testes a fazer no telemóvel.
